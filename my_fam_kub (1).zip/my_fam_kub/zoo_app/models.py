# zoo_app/models.py
from django.db import models
from django.utils import timezone
import re
# --- Make sure this import is present ---
from django.contrib.auth.models import User

class AnimalCategory(models.Model):
    name = models.CharField(max_length=100, unique=True)
    def __str__(self):
        return self.name

class Animal(models.Model):
    category = models.ForeignKey(AnimalCategory, related_name='animals', on_delete=models.SET_NULL, null=True)
    name = models.CharField(max_length=100)
    description = models.TextField(blank=True)
    image_upload = models.ImageField(upload_to='animal_images/', null=True, blank=True, verbose_name="1. อัปโหลดรูป (จากเครื่อง)")
    image_url = models.URLField(null=True, blank=True, verbose_name="2. หรือ วางลิงก์รูป (จาก Google)")
    video_url = models.URLField(null=True, blank=True, verbose_name="3. (ถ้ามี) ลิงก์วิดีโอ (YouTube)")

    def __str__(self):
        return self.name

    def get_youtube_embed_url(self):
        # ... (function code remains the same) ...
        if not self.video_url: return None
        video_id = None
        regex = r"^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*"
        match = re.search(regex, self.video_url)
        if match and len(match.group(2)) == 11: video_id = match.group(2)
        if video_id: return f"https://www.youtube.com/embed/{video_id}?autoplay=1&mute=1&playsinline=1"
        return None

class TicketType(models.Model):
    name = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=8, decimal_places=2)
    def __str__(self):
        return f"{self.name} ({self.price} บาท)"

# --- IMPORTANT: Ensure the Booking model has the 'user' field ---
class Booking(models.Model):
    # --- This ForeignKey line MUST be present ---
    user = models.ForeignKey(User, on_delete=models.CASCADE, verbose_name="ผู้จอง")

    # --- Other fields remain the same ---
    full_name = models.CharField(max_length=150, verbose_name="ชื่อ-นามสกุล (ตามหน้าตั๋ว)")
    email = models.EmailField(verbose_name="อีเมล (สำหรับรับตั๋ว)")
    visit_date = models.DateField(verbose_name="วันที่เข้าชม")
    ticket_type = models.ForeignKey(TicketType, on_delete=models.PROTECT, verbose_name="ประเภทตั๋ว")
    quantity = models.PositiveIntegerField(default=1, verbose_name="จำนวน")
    booking_time = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        # Make sure this uses self.user.username
        return f"Booking by {self.user.username} for {self.full_name} on {self.visit_date}"

    @property
    def total_price(self):
        if self.ticket_type and self.ticket_type.price is not None:
             return self.ticket_type.price * self.quantity
        return 0
# --- End Booking model ---