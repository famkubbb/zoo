# zoo_app/forms.py
from django import forms
from .models import Booking # <-- ต้อง import Booking
from django.utils import timezone
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User

# --- (SignUpForm ไม่ต้องแก้) ---
class SignUpForm(UserCreationForm):
    email = forms.EmailField(
        max_length=254, required=True, label='อีเมล',
        help_text='*จำเป็น กรุณากรอกอีเมลที่ใช้งานได้',
        widget=forms.EmailInput(attrs={'class': 'form-control'})
    )
    # (ถ้าเอา first_name, last_name ออกแล้ว โค้ดส่วนนี้จะไม่มี)

    class Meta:
        model = User
        # fields = ('username', 'email') # <-- ถ้าเอาชื่อออกแล้ว
        fields = ('username', 'first_name', 'last_name', 'email') # <-- ถ้ายังมีชื่ออยู่
        labels = {'username': 'ชื่อผู้ใช้ (Username)'}
        help_texts = {'username': '*จำเป็น กรอกได้เฉพาะตัวอักษรภาษาอังกฤษ ตัวเลข และ @/./+/-/_ เท่านั้น'}
        widgets = {'username': forms.TextInput(attrs={'class': 'form-control'})}

    def __init__(self, *args, **kwargs):
        super(SignUpForm, self).__init__(*args, **kwargs)
        self.fields['password1'].widget = forms.PasswordInput(attrs={'class': 'form-control'})
        self.fields['password1'].label = 'รหัสผ่าน'
        self.fields['password1'].help_text = '*จำเป็น รหัสผ่านของคุณต้องไม่ง่ายเกินไปและต้องมีความยาวอย่างน้อย 8 ตัวอักษร'
        self.fields['password2'].widget = forms.PasswordInput(attrs={'class': 'form-control'})
        self.fields['password2'].label = 'ยืนยันรหัสผ่าน'
        self.fields['password2'].help_text = '*จำเป็น กรุณากรอกรหัสผ่านเหมือนช่องบนอีกครั้งเพื่อยืนยัน'

# --- (สำคัญ!) แก้ไข BookingForm ---
class BookingForm(forms.ModelForm):
    class Meta:
        # --- !!! เพิ่มบรรทัดนี้เข้าไป !!! ---
        model = Booking
        # ------------------------------------
        fields = ['full_name', 'email', 'visit_date', 'ticket_type', 'quantity']
        widgets = {
            'visit_date': forms.DateInput(attrs={'type': 'date', 'class': 'form-control'}),
            'full_name': forms.TextInput(attrs={'class': 'form-control'}),
            'email': forms.EmailInput(attrs={'class': 'form-control'}),
            'ticket_type': forms.Select(attrs={'class': 'form-select'}),
            'quantity': forms.NumberInput(attrs={'class': 'form-control', 'min': 1}),
        }

    def clean_visit_date(self):
        date = self.cleaned_data.get('visit_date')
        if date and date < timezone.localdate():
            raise forms.ValidationError("ไม่สามารถเลือกวันที่ผ่านมาแล้วได้")
        return date