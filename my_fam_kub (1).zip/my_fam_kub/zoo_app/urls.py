# zoo_app/urls.py

from django.urls import path
from . import views  # Import views

app_name = 'zoo_app' 

urlpatterns = [
    # Paths จากไฟล์ views.py ของคุณ
    path('', views.home, name='home'),
    path('animals/', views.animal_list, name='animal_list'),
    
    # Path สำหรับหน้าจอง (เรียก views.booking_create)
    path('booking/new/', views.booking_create, name='booking_create'), 
    
    path('booking/history/', views.booking_history, name='booking_history'),
    path('booking/success/', views.booking_success, name='booking_success'),
    path('booking/cancel/<int:booking_id>/', views.cancel_booking, name='cancel_booking'),
    
    # --- นี่คือบรรทัดที่เพิ่มเข้ามาเพื่อแก้ Error ---
    # เราต้องเพิ่ม Path นี้เข้าไป เพื่อให้ {% url 'zoo_app:ticket_detail' ... %} ทำงาน
    path('ticket/<int:booking_id>/', views.ticket_detail_view, name='ticket_detail'),
    
    # Path สำหรับ Signup
    path('signup/', views.SignUpView.as_view(), name='signup'), 
]