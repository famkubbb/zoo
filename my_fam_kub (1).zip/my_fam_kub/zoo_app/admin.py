# zoo_app/admin.py
from django.contrib import admin
# บรรทัดนี้จะ import ทุกอย่างที่เราเพิ่งเพิ่มใน models.py
from .models import AnimalCategory, Animal, TicketType, Booking

# ลงทะเบียนโมเดลทั้งหมด
admin.site.register(AnimalCategory)
admin.site.register(Animal)
admin.site.register(TicketType)
admin.site.register(Booking)