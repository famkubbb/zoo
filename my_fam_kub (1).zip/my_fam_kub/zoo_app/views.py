# zoo_app/views.py

from django.shortcuts import render, redirect, get_object_or_404
from .models import Animal, AnimalCategory, TicketType, Booking
from .forms import BookingForm, SignUpForm
from django.contrib.auth.decorators import login_required
from django.contrib.auth import login
from django.urls import reverse_lazy
from django.views import generic
# --- 1. Import send_mail and settings ---
from django.core.mail import send_mail
from django.conf import settings
from django.contrib import messages # For cancel_booking messages

def home(request):
    return render(request, 'home.html')

def animal_list(request):
    all_categories = AnimalCategory.objects.all()
    animals_queryset = Animal.objects.select_related('category').all()
    search_query = request.GET.get('q', '')
    if search_query:
        animals_queryset = animals_queryset.filter(name__icontains=search_query)
    category_filter_id = request.GET.get('category', '')
    selected_category = None
    if category_filter_id:
        try:
            category_id = int(category_filter_id)
            animals_queryset = animals_queryset.filter(category__id=category_id)
            selected_category = all_categories.get(id=category_id)
        except (ValueError, AnimalCategory.DoesNotExist):
            pass
    context = {
        'all_categories': all_categories, 'animals': animals_queryset,
        'search_query': search_query, 'selected_category': selected_category,
    }
    return render(request, 'animal_list.html', context)

class SignUpView(generic.CreateView):
    form_class = SignUpForm
    success_url = reverse_lazy('login')
    template_name = 'registration/signup.html'

@login_required
def booking_create(request):
    if request.method == 'POST':
        form = BookingForm(request.POST)
        if form.is_valid():
            booking = form.save(commit=False)
            booking.user = request.user
            booking.save()

            # --- 2. Send Email Notification ---
            try:
                subject = f'มีการจองตั๋วใหม่ - สวนสัตว์จักกะจี้จุกจิก ({booking.id})'
                message_body = (
                    f"มีการจองตั๋วใหม่เข้าระบบ:\n\n"
                    f"ผู้ใช้: {booking.user.username}\n"
                    f"ชื่อบนตั๋ว: {booking.full_name}\n"
                    f"อีเมลติดต่อ: {booking.email}\n"
                    f"วันที่เข้าชม: {booking.visit_date.strftime('%d/%m/%Y')}\n"
                    f"ประเภทตั๋ว: {booking.ticket_type.name}\n"
                    f"จำนวน: {booking.quantity}\n"
                    f"ราคารวม: {booking.total_price} บาท\n"
                    f"เวลาที่จอง: {booking.booking_time.strftime('%d/%m/%Y %H:%M:%S')}\n"
                )
                from_email = settings.EMAIL_HOST_USER
                # !!! Replace with the email address where you want to receive notifications !!!
                recipient_list = ['sanhanat4525@gmail.com'] 

                send_mail(subject, message_body, from_email, recipient_list, fail_silently=False)
                print("Booking notification email sent successfully.") # Log success

            except Exception as e:
                print(f"Error sending booking email: {e}") # Log errors
            # --- End Email Sending ---

            # แก้ไขตามที่คุณต้องการ: ไปหน้าประวัติการจอง
            return redirect('zoo_app:booking_history') 
        else:
            print("Booking form errors:", form.errors) # Log form errors if invalid
    else:
        form = BookingForm()

    context = {
        'form': form,
        'ticket_types': TicketType.objects.all()
    }
    return render(request, 'booking_form.html', context)

def booking_success(request):
    return render(request, 'booking_success.html')

@login_required
def booking_history(request):
    user_bookings = Booking.objects.filter(user=request.user).order_by('-booking_time')
    context = { 'bookings': user_bookings, }
    return render(request, 'booking_history.html', context)

@login_required
def cancel_booking(request, booking_id):
    booking_to_cancel = get_object_or_404(Booking, id=booking_id, user=request.user)
    booking_to_cancel.delete()
    messages.success(request, f'การจองสำหรับวันที่ {booking_to_cancel.visit_date.strftime("%d/%m/%Y")} ถูกยกเลิกเรียบร้อยแล้ว')
    return redirect('zoo_app:booking_history')

# --- (นี่คือฟังก์ชันใหม่ที่เราเพิ่มเข้ามา) ---
@login_required
def ticket_detail_view(request, booking_id):
    """
    View สำหรับแสดงตั๋วใบเดียว (ticket_confirmation.html)
    """
    # ดึงข้อมูลการจอง "ใบเดียว" ตาม ID 
    # และตรวจสอบว่าเป็นของ user ที่ login อยู่
    booking = get_object_or_404(Booking, id=booking_id, user=request.user)
    
    # (สำคัญ!) ตรวจสอบว่าคุณมี template 'ticket_confirmation.html' 
    # ในโฟลเดอร์ templates/zoo_app/
    return render(request, 'ticket_confirmation.html', {
        'booking': booking # ส่ง 'booking' ใบนี้ไปให้ template
    })