# my_fam_kub/urls.py
from django.contrib import admin
from django.urls import path, include # <-- ตรวจสอบว่ามี include
from django.conf import settings
from django.conf.urls.static import static

urlpatterns = [
    path('admin/', admin.site.urls),
    
    # --- (ใหม่!) เพิ่ม URL สำหรับระบบ Auth ของ Django ---
    # มันจะหา template ใน 'templates/registration/'
    path('accounts/', include('django.contrib.auth.urls')), 
    
    # --- URL ของแอปเรา (เหมือนเดิม) ---
    path('', include('zoo_app.urls')), 
]

# --- ส่วนแสดง Media (เหมือนเดิม) ---
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
    # (ถ้ามี static ด้วยก็ใส่)
    # urlpatterns += static(settings.STATIC_URL, document_root=settings.STATIC_ROOT)